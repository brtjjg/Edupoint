const plans = document.querySelectorAll(".plan");
const planInput = document.getElementById("plan");
const amountInput = document.getElementById("amount");
const form = document.getElementById("paymentForm");
const message = document.getElementById("message");
const statusBox = document.getElementById("status");

plans.forEach((button, index) => {
  button.addEventListener("click", () => {
    plans.forEach(x => x.classList.remove("active"));
    button.classList.add("active");
    planInput.value = button.dataset.plan;
    amountInput.value = `KES ${button.dataset.amount}`;
  });
  if (index === 0) button.classList.add("active");
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  message.textContent = "Starting secure payment request...";
  statusBox.textContent = "Waiting for payment...";
  const payload = {
    plan: planInput.value,
    provider: document.getElementById("provider").value,
    phone: document.getElementById("phone").value.trim()
  };

  try {
    const res = await fetch("/api/payment/initiate", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || "Payment failed to start.");

    message.textContent = data.message;
    if (data.instructions?.length) {
      message.textContent += " " + data.instructions.join(" ");
    }

    let tries = 0;
    const timer = setInterval(async () => {
      tries++;
      const check = await fetch(`/api/payment/status/${encodeURIComponent(data.transaction_id)}`);
      const state = await check.json();
      if (!state.ok) return;
      statusBox.textContent = `Transaction ${data.transaction_id}: ${state.payment.status}`;
      if (["paid","failed"].includes(state.payment.status) || tries >= 40) {
        clearInterval(timer);
        if (state.payment.status === "paid") {
          message.textContent = "Payment confirmed. Premium access can now be unlocked.";
        }
      }
    }, 3000);
  } catch (err) {
    message.textContent = err.message;
    statusBox.textContent = "Payment not completed.";
  }
});
